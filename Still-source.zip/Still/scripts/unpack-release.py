#!/usr/bin/env python3
"""Validate and unpack a single Still source ZIP without executing archive code."""
from pathlib import Path, PurePosixPath
import os
import re
import stat
import sys
import zipfile

MAX_FILES = 4000
MAX_UNCOMPRESSED = 256 * 1024 * 1024
REQUIRED = ('project.yml', 'scripts/build-ipa.sh', 'Packages/ReceiverCore/Package.swift', 'Still/Resources/documents.json', 'android-sender/settings.gradle', 'relay/package-lock.json')

def unpack(archive, destination):
    destination = Path(destination)
    if destination.is_symlink() or (destination.exists() and not destination.is_dir()):
        raise ValueError("Extraction directory must be a real directory.")
    if destination.exists() and any(destination.iterdir()):
        raise ValueError('Extraction directory must be empty.')
    with zipfile.ZipFile(archive) as source:
        entries = source.infolist()
        if not entries or len(entries) > MAX_FILES or sum(e.file_size for e in entries) > MAX_UNCOMPRESSED:
            raise ValueError('Archive is empty or exceeds the build limits.')
        paths = []
        for entry in entries:
            name = entry.filename
            parts = PurePosixPath(name).parts
            mode = entry.external_attr >> 16
            if not parts or name.startswith('/') or '\\' in name or any(p in ('.', '..') or ':' in p for p in parts):
                raise ValueError('Archive contains an unsafe path.')
            if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)) or entry.flag_bits & 1:
                raise ValueError('Links, special files and encrypted entries are not supported.')
            paths.append((entry, parts))
        names = {entry.filename.rstrip('/') for entry in entries}
        if 'project.yml' in names:
            prefix = ()
        else:
            roots = {parts[0] for _, parts in paths}
            if len(roots) != 1:
                raise ValueError('ZIP must contain one Still project folder.')
            prefix = (next(iter(roots)),)
        planned = []
        seen = set()
        for entry, parts in paths:
            relative = parts[len(prefix):]
            if not relative:
                continue
            canonical = '/'.join(relative)
            if canonical.casefold() in seen:
                raise ValueError('Archive contains duplicate or case-colliding paths.')
            seen.add(canonical.casefold())
            planned.append((entry, relative))
        files = {'/'.join(relative) for entry, relative in planned if not entry.is_dir()}
        if not all(required in files for required in REQUIRED):
            raise ValueError('ZIP is missing required Still source files. Upload the supplied Still-source.zip.')
        destination.mkdir(parents=True, exist_ok=True)
        for entry, relative in planned:
            target = destination.joinpath(*relative)
            if entry.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with source.open(entry) as stream, target.open('xb') as output:
                    import shutil
                    shutil.copyfileobj(stream, output)
                target.chmod(0o755 if relative[0] == 'scripts' and target.suffix == '.sh' else 0o644)
    match = re.search(r'''(?m)^\s*MARKETING_VERSION:\s*['"]?([0-9]+\.[0-9]+\.[0-9]+)['"]?\s*$''', (destination / 'project.yml').read_text())
    if not match:
        raise ValueError('project.yml must contain a numeric MARKETING_VERSION.')
    return match.group(1)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: unpack-release.py source.zip destination')
    version = unpack(sys.argv[1], sys.argv[2])
    if os.environ.get('GITHUB_OUTPUT'):
        with open(os.environ['GITHUB_OUTPUT'], 'a') as output:
            output.write('app_version=' + version + '\n')
    print('Validated and extracted Still ' + version + '.')
