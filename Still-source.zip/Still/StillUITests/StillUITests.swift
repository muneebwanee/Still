import XCTest

@MainActor final class StillUITests: XCTestCase {
    private func attachFailureContext() {
        let app = XCUIApplication()
        let image = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        image.name = "Screen at UI test failure"
        image.lifetime = .keepAlways
        add(image)
        let hierarchy = XCTAttachment(string: app.debugDescription)
        hierarchy.name = "Accessibility hierarchy at UI test failure"
        hierarchy.lifetime = .keepAlways
        add(hierarchy)
    }

    private func element(_ identifier: String, in app: XCUIApplication) -> XCUIElement {
        // SwiftUI NavigationLink can be exposed as either a button or a link.
        app.descendants(matching: .any).matching(identifier: identifier).firstMatch
    }

    private func waitUntil(_ description: String, timeout: TimeInterval = 10,
                           file: StaticString = #filePath, line: UInt = #line,
                           condition: @escaping () -> Bool) {
        let predicate = NSPredicate { _, _ in condition() }
        let expectation = XCTNSPredicateExpectation(predicate: predicate, object: nil)
        let result = XCTWaiter.wait(for: [expectation], timeout: timeout)
        if result != .completed { attachFailureContext() }
        XCTAssertEqual(result, .completed, description, file: file, line: line)
    }

    private func launch() -> XCUIApplication {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--uitesting-reset"]
        app.launch()
        XCTAssertTrue(element("welcome.scroll", in: app).waitForExistence(timeout: 15))
        return app
    }

    private func reveal(_ control: XCUIElement, inside container: XCUIElement,
                        app: XCUIApplication, file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertTrue(container.waitForExistence(timeout: 10), "Expected the active page", file: file, line: line)
        waitUntil("The active page must finish presenting", file: file, line: line) { container.isHittable }
        for _ in 0..<12 {
            // SwiftUI can report an offscreen Form row as hittable. Require its complete
            // frame to be inside the visible scroll viewport before sending a tap.
            let viewport = container.frame.intersection(app.windows.firstMatch.frame).insetBy(dx: 8, dy: 24)
            if control.exists, !control.frame.isEmpty,
               control.frame.minY >= viewport.minY, control.frame.maxY <= viewport.maxY,
               viewport.contains(CGPoint(x: control.frame.midX, y: control.frame.midY)), control.isHittable { return }
            let needsDownwardScroll = control.exists && !control.frame.isEmpty && control.frame.midY < viewport.minY
            let start = container.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: needsDownwardScroll ? 0.25 : 0.78))
            let end = container.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: needsDownwardScroll ? 0.78 : 0.25))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        attachFailureContext()
        XCTFail("Control did not become fully visible in its own page: \(control)", file: file, line: line)
    }

    private func enterApp(_ app: XCUIApplication) {
        let scroll = element("welcome.scroll", in: app)
        let start = element("welcome.start", in: app)
        reveal(start, inside: scroll, app: app)
        start.tap()
        waitUntil("Welcome must dismiss before using the home screen") { !scroll.exists }
        XCTAssertTrue(element("home.settings", in: app).waitForExistence(timeout: 10))
    }

    private func openSettings(_ app: XCUIApplication) -> XCUIElement {
        let button = element("home.settings", in: app)
        waitUntil("Settings button must be ready") { button.exists && button.isHittable }
        button.tap()
        let form = element("settings.form", in: app)
        XCTAssertTrue(form.waitForExistence(timeout: 10))
        return form
    }

    private func setQueueOnly(_ enabled: Bool, app: XCUIApplication, form: XCUIElement) {
        let control = app.switches["settings.queueOnly"]
        reveal(control, inside: form, app: app)
        let expected = enabled ? "1" : "0"
        guard control.value as? String != expected else { return }
        // Tap the switch's trailing thumb, not the center of its combined label/row.
        control.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
        waitUntil("Queue-only switch must change after the user action") { control.value as? String == expected }
    }

    func testLegalLibraryIsAvailableBeforeOnboarding() {
        let app = launch()
        let library = element("welcome.legal", in: app)
        reveal(library, inside: element("welcome.scroll", in: app), app: app)
        library.tap()
        let list = element("legal.library", in: app)
        let eula = element("legal.document.eula", in: app)
        reveal(eula, inside: list, app: app)
        eula.tap()
        XCTAssertTrue(element("legal.page.eula", in: app).waitForExistence(timeout: 10))
        XCTAssertTrue(app.staticTexts["In plain words"].exists)
        XCTAssertTrue(app.buttons["Share this document"].exists)
    }

    func testQueueOnlyPreferenceSurvivesRelaunch() {
        let app = launch()
        enterApp(app)
        let form = openSettings(app)
        let control = app.switches["settings.queueOnly"]
        reveal(control, inside: form, app: app)
        XCTAssertEqual(control.value as? String, "0")
        setQueueOnly(true, app: app, form: form)
        element("settings.done", in: app).tap()
        waitUntil("Settings must dismiss") { !form.exists }
        XCUIDevice.shared.press(.home)
        waitUntil("App must enter the background") { app.state != .runningForeground }
        app.terminate()
        app.launchArguments = []
        app.launch()
        let restored = openSettings(app)
        reveal(control, inside: restored, app: app)
        waitUntil("The saved queue-only choice must survive relaunch") { control.value as? String == "1" }
    }

    func testLocalWipeReturnsToWelcomeAndResetsPreferences() {
        let app = launch()
        enterApp(app)
        let form = openSettings(app)
        setQueueOnly(true, app: app, form: form)
        let privacy = element("settings.privacy", in: app)
        reveal(privacy, inside: form, app: app)
        privacy.tap()
        let privacyForm = element("privacy.form", in: app)
        XCTAssertTrue(privacyForm.waitForExistence(timeout: 10), "Privacy navigation must succeed before looking for Wipe")
        let wipe = element("privacy.wipe", in: app)
        reveal(wipe, inside: privacyForm, app: app)
        wipe.tap()
        let confirmation = app.buttons["Stop & wipe local data"]
        XCTAssertTrue(confirmation.waitForExistence(timeout: 10))
        confirmation.tap()
        XCTAssertTrue(element("welcome.scroll", in: app).waitForExistence(timeout: 30))
        enterApp(app)
        let resetForm = openSettings(app)
        let control = app.switches["settings.queueOnly"]
        reveal(control, inside: resetForm, app: app)
        waitUntil("Local wipe must reset the saved queue-only choice") { control.value as? String == "0" }
    }
}
