# Validation record · Still 1.2

Validated in the Linux authoring workspace on November 10, 2026:

- Nine Node local-remote tests and five offline-document tests. Public, iOS-bundled, Android-bundled and NCL texts are checked for consistency.
- Eight live-WebSocket relay tests: room authentication, invitation/owner separation, sender cap, offer/answer roles, recording opt-in, receiver resume, TURN REST credentials, foreign-origin rejection, room bounds and malformed input.
- Chromium local-remote integration with an HTTP fixture: pairing, fragment removal, commands, queue, text safety, missing tokens, phone/tablet layouts, themes, reduced motion and queue-only behavior.
- Chromium WebRTC media integration through an isolated loopback coturn TCP relay: actual encoded/decoded video frames between sender and receiver pages, invitation-fragment removal, explicit capture action, video-only request, recording permission/notice, receiver reconnection without recapture, stop cleanup and mobile layout. Capture used a controlled animated canvas, not the real OS screen picker. No public relay was deployed.
- The managed Chromium policy disables non-proxied UDP. Direct-path browser media could not be established here; the TURN/TCP test used the supported fallback without changing that policy. Direct paths still need verification in an appropriate device/network environment.
- All three Android Java source files compiled with Eclipse ECJ against the official Android 36 platform and pinned Android WebRTC/OkHttp/Okio/Kotlin classes. This is source/API compilation, not APK packaging, Android lint, device permission or lifecycle testing.
- Twenty-one Swift files passed tree-sitter syntax parsing. This does not type-check Apple or WebRTC SDK APIs and is not a native build.
- Relay dependency audit: zero reported production vulnerabilities at the time checked, after updating ws to 8.22.2. No audit can guarantee absence of defects.
- Project/workflow/compose YAML, asset/catalog JSON, Android manifest/resource XML, Info.plist, privacy manifest, shell and JavaScript syntax checked.

Authored but not executed here: Swift package tests, two native MP4 recording tests, three iOS UI tests, iOS builds, Android Gradle build/lint and GitHub workflows. No IPA/APK was generated or signed here. Native capture, native recording, PiP, actual background media behavior, performance, accessibility and production HTTPS/TURN deployment need real platform validation.

Screenshots depict browser fixtures, not the native iOS app. No zero-latency, uninterrupted-connection or indefinite iOS background-receiving guarantee is made. See RELEASE.md before distribution.

## ZIP-to-release bootstrap

The standalone build-release.yml now supports uploading the source ZIP directly to a repository. Six local extraction tests passed, including the supplied archive, flat/wrapped projects, traversal/collision rejection, symlink rejection, required-file checks and destination protection. Actionlint 1.7.12 accepted the workflow; all embedded shell scripts and five embedded Python blocks passed syntax checks. The workflow has not been executed on GitHub and no release was published during authoring. Simulator compilation/tests, signing and Android packaging still require the first actual runner execution.

## Xcode 16.4 heartbeat build fix

The first user-run GitHub simulator build reached Swift compilation and reported a missing `pongReceiveHandler` argument in ScreenSession: Xcode 16.4 exposes WebSocket ping through its completion-handler API. The replacement ZIP bridges that callback with a checked throwing continuation and keeps the existing awaited heartbeat/reconnect behavior. PiP delegate callbacks now conform nonisolated and dispatch UI mutations to the main actor; WebRTC async helpers remain main-actor isolated, with a preconcurrency import for the legacy Objective-C module. This addresses the supplied compiler error and warnings. It is not evidence of a successful subsequent Xcode build; the replacement ZIP must be committed and built on GitHub. Tests and release gates remain enabled.

## November 11 · UI navigation and SDK setup fix

Read-only inspection of the user-run workflow https://github.com/muneebwanee/Still/actions/runs/42842268741 confirmed: app compilation succeeded; all eight ReceiverCore tests and both native recording tests passed; offline legal UI access passed. Wipe navigation failed before the wipe action was reached. The queue-only UI action reported no state transition immediately after tapping, so those failures alone did not establish a persistent-store defect.

The replacement source adds stable identifiers, bounds-aware scrolling inside each active form, explicit waits for page transitions and switch state, a trailing-switch hit target, and a background/relaunch persistence check. Tests continue to exercise actual UI actions and fail if changes do not occur. Launch-fixture reset is now once per process, and presentation teardown cannot implicitly mark onboarding complete during local wipe. Failure screenshots/hierarchies are attached. These revised iOS UI tests still need a macOS simulator run; Linux parsing is not UI execution.

The same GitHub run exposed an independent Android setup failure: setup-android v3 requested removed package `tools`. Both the standalone ZIP workflow and extracted-source Android workflow now explicitly request `platform-tools`, `platforms;android-36` and `build-tools;36.0.0`. The active repository workflow must be replaced along with the ZIP. Release test gates remain enabled.
