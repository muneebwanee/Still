# Upload ZIP → build → GitHub release

You need two downloads: **Still-source.zip** and **build-release.yml**. Keep the ZIP named exactly `Still-source.zip`. You do not need to extract it or upload individual app files.

## First build

1. Create an empty GitHub repository, or open the repository you want to use. Its default branch should be `main` or `master` for automatic builds.
2. Use **Add file → Upload files** to upload `Still-source.zip` into the repository root, then commit it.
3. Use **Add file → Create new file**. In the filename field enter **`.github/workflows/build-release.yml`**. Copy the complete contents of the downloaded `build-release.yml` into the editor, then commit it. A workflow placed at the repository root will not run.
4. Open **Actions → Build ZIP and release**. It should start automatically after the workflow commit. If Actions is disabled, enable it for the repository. You can also choose **Run workflow** on the default branch.
5. Wait for **Unpack ZIP and validate**, **Test and build iOS IPA**, the optional Android job, and **Publish GitHub prerelease** to turn green. The iOS simulator tests can make this take a while.
6. Open the repository’s **Releases** page, or use the release link in the workflow summary. Expand **Assets** to download the IPA, optional APK, source ZIP and `SHA256SUMS.txt`.

After setup, replacing `Still-source.zip` with a newer supplied ZIP and committing it starts another build. Each successful run creates a separately tagged build prerelease. Re-running the same workflow run updates that run’s generated assets.

## What you get by default

- `Still-1.2.0-unsigned.ipa` — an iOS archive packaged for signing. **It cannot be installed directly.** You must sign it with an appropriate Apple certificate/profile or a legitimate sideloading setup first.
- `Still-Sender-1.2.0-debug.apk` — the Android companion test build, if enabled. This is debug-signed for testing, not a Play Store release. Its generated debug signing key can change between CI runs, so replacing an older test build may require uninstalling that older copy.
- `Still-source.zip` — the source uploaded for that build.
- `SHA256SUMS.txt` — checksums of the attached files.

GitHub marks these as **prereleases** because they are build/test artifacts. Passing automated tests does not replace physical-device testing or store review. No public HTTPS/TURN screen-sharing service is deployed by this workflow.

## Optional signed iOS build

The same workflow can export a signed IPA. You do not need to edit the YAML. In **Settings → Secrets and variables → Actions**, add these repository **secrets**:

| Secret name | What goes in it |
| --- | --- |
| `APPLE_TEAM_ID` | Your 10-character Apple Developer team ID |
| `IOS_CERTIFICATE_BASE64` | Base64-encoded Apple Distribution `.p12`, including its private key |
| `IOS_CERTIFICATE_PASSWORD` | Password for that `.p12` |
| `IOS_PROFILE_BASE64` | Base64-encoded matching provisioning profile |

If your registered app identifier differs from `com.muneebwanee.still`, add repository **variable** `IOS_BUNDLE_ID` with your registered identifier. The certificate, team, profile and bundle ID must match. The profile must not be expired. Do not commit signing material or paste secrets into chat.

Then open **Actions → Build ZIP and release → Run workflow**:

- Enable **Sign the IPA using Apple credentials in repository Secrets**.
- Select **release-testing** for an ad hoc distribution profile. Only iPhones/iPads whose UDIDs are registered in that profile can install the resulting IPA.
- Select **app-store-connect** for an App Store distribution profile. That IPA is for upload to App Store Connect/TestFlight, not direct installation. This workflow does not submit it to Apple.
- Leave **Also build the Android screen sender test APK** enabled, or turn it off if you only want the IPA.

Push-triggered builds use the unsigned defaults. A signed export is explicitly selected through Run workflow. Apple signing cannot be supplied by GitHub automatically; you must obtain the appropriate Apple credentials first.

## If a build fails

Open the red job and expand the failing step. The workflow publishes a release only after its required jobs succeed. Simulator results are retained as a separate Actions artifact when available; they are not attached as release binaries.

- **Missing ZIP:** place `Still-source.zip` at the repository root and preserve its exact name.
- **Workflow not listed:** ensure the file is at `.github/workflows/build-release.yml` on the default branch, not inside the ZIP or at the repository root. On another branch name, use Run workflow or adjust the two branch names in the YAML.
- **Apple signing error:** check secret names, certificate private key, password, profile expiry, team, bundle ID and selected distribution method.
- **Release permission error:** the release job requests `contents: write`. Repository or organization policy must allow that token permission and GitHub Releases. An administrator may need to change the policy.
- **Compile/test error:** retain the exact error message and failing job. Native iOS/Android packaging has not been executed from the Linux authoring workspace, so a first GitHub run may reveal SDK, build or device-test issues that require a source fix. No successful remote build is claimed before you run it.

The ZIP bootstrap, embedded Python/shell syntax and workflow structure were checked locally. GitHub Actions execution, Apple signing, APK assembly and device validation remain separate checks.
